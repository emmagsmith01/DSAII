#include "MyMesh.h"
void MyMesh::GenerateCube(float a_fSize, vector3 a_v3Color)
{
	if (a_fSize < 0.01f)
		a_fSize = 0.01f;

	Release();
	Init();

	float fValue = a_fSize * 0.5f;
	//3--2
	//|  |
	//0--1

	vector3 point0(-fValue, -fValue, fValue); //0
	vector3 point1(fValue, -fValue, fValue); //1
	vector3 point2(fValue, fValue, fValue); //2
	vector3 point3(-fValue, fValue, fValue); //3

	vector3 point4(-fValue, -fValue, -fValue); //4
	vector3 point5(fValue, -fValue, -fValue); //5
	vector3 point6(fValue, fValue, -fValue); //6
	vector3 point7(-fValue, fValue, -fValue); //7

	//F
	AddQuad(point0, point1, point3, point2);

	//B
	AddQuad(point5, point4, point6, point7);

	//L
	AddQuad(point4, point0, point7, point3);

	//R
	AddQuad(point1, point5, point2, point6);

	//U
	AddQuad(point3, point2, point7, point6);

	//D
	AddQuad(point4, point5, point0, point1);

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateCone(float a_fRadius, float a_fHeight, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fRadius < 0.01f)
		a_fRadius = 0.01f;

	if (a_fHeight < 0.01f)
		a_fHeight = 0.01f;

	if (a_nSubdivisions < 3)
		a_nSubdivisions = 3;
	if (a_nSubdivisions > 360)
		a_nSubdivisions = 360;

	Release();
	Init();

	// Replace this with your code
	std::vector<vector3> vertex;
	GLfloat theta = 0;
	GLfloat delta = static_cast<GLfloat>(2.0 * PI / static_cast<GLfloat>(a_nSubdivisions));
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		vector3 temp = vector3(cos(theta) * a_fRadius, sin(theta) * a_fRadius, -a_fHeight / 2.0f);
		theta += delta;
		vertex.push_back(temp);
	}

	vector3 origin = vector3(0.0f, 0.0f, a_fHeight / 2.0f);
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		AddTri(origin, vertex[i], vertex[(i + 1) % a_nSubdivisions]);
	}

	origin = vector3(0.0f, 0.0f, -a_fHeight / 2.0f);
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		AddTri(origin, vertex[(i + 1) % a_nSubdivisions], vertex[i]);
	}
	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateCylinder(float a_fRadius, float a_fHeight, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fRadius < 0.01f)
		a_fRadius = 0.01f;

	if (a_fHeight < 0.01f)
		a_fHeight = 0.01f;

	if (a_nSubdivisions < 3)
		a_nSubdivisions = 3;
	if (a_nSubdivisions > 360)
		a_nSubdivisions = 360;

	Release();
	Init();

	// Replace this with your code

	// generate circle of points
	std::vector<vector3> vertex;
	GLfloat theta = 0;
	GLfloat delta = static_cast<GLfloat>(2.0 * PI / static_cast<GLfloat>(a_nSubdivisions));
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		vector3 temp = vector3(cos(theta) * a_fRadius, sin(theta) * a_fRadius, 0.0f);
		theta += delta;
		vertex.push_back(temp);
	}

	// modify those points in a negative height
	std::vector<vector3> vertexTop;
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		vertexTop.push_back(vertex[i] + vector3(0.0f, 0.0f, -a_fHeight / 2.0f));
	}

	// modify those points in a positive height
	std::vector<vector3> vertexBottom;
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		vertexBottom.push_back(vertex[i] + vector3(0.0f, 0.0f, a_fHeight / 2.0f));
	}

	//draw top circle
	vector3 origin = vector3(0.0f, 0.0f, -a_fHeight / 2.0f);
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		AddTri(origin, vertexTop[(i + 1) % a_nSubdivisions], vertexTop[i]);
	}

	//draw bottom circle
	origin = vector3(0.0f, 0.0f, a_fHeight / 2.0f);
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		AddTri(origin, vertexBottom[i], vertexBottom[(i + 1) % a_nSubdivisions]);
	}

	//first tri
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		AddTri(vertexBottom[i], vertexTop[i], vertexBottom[(i + 1) % a_nSubdivisions]);
	}

	for (int i = 0; i < a_nSubdivisions; i++)
	{
		AddTri(vertexBottom[(i + 1) % a_nSubdivisions], vertexTop[i], vertexTop[(i + 1) % a_nSubdivisions]);
	}


	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateTube(float a_fOuterRadius, float a_fInnerRadius, float a_fHeight, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fOuterRadius < 0.01f)
		a_fOuterRadius = 0.01f;

	if (a_fInnerRadius < 0.005f)
		a_fInnerRadius = 0.005f;

	if (a_fInnerRadius > a_fOuterRadius)
		std::swap(a_fInnerRadius, a_fOuterRadius);

	if (a_fHeight < 0.01f)
		a_fHeight = 0.01f;

	if (a_nSubdivisions < 3)
		a_nSubdivisions = 3;
	if (a_nSubdivisions > 360)
		a_nSubdivisions = 360;

	Release();
	Init();

	// Replace this with your code
	GLfloat delta = static_cast<GLfloat>(2.0 * PI / static_cast<GLfloat>(a_nSubdivisions));
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		GLfloat currentAngle = delta * i; // one line of subdivision
		GLfloat prevAngle = delta * (i - 1); // other line of subdivision

		GLfloat outerX1 = (a_fOuterRadius * cos(currentAngle)); //cos (x) outer line current angle
		GLfloat outerY1 = (a_fOuterRadius * sin(currentAngle)); //sin (y) outer line current angle
		GLfloat outerX0 = (a_fOuterRadius * cos(prevAngle)); //cos (x) outer line prev angle
		GLfloat outerY0 = (a_fOuterRadius * sin(prevAngle)); //sin (y) outer line prev angle

		GLfloat innerX1 = (a_fInnerRadius * cos(currentAngle)); //cos (x) inner line current angle
		GLfloat innerY1 = (a_fInnerRadius * sin(currentAngle)); //sin (y) inner line current angle
		GLfloat innerX0 = (a_fInnerRadius * cos(prevAngle)); //cos (x) inner line prev angle
		GLfloat innerY0 = (a_fInnerRadius * sin(prevAngle)); //sin (y) inner line prev angle

		//top circle
		AddQuad(vector3(outerX1, a_fHeight / 2, outerY1), vector3(outerX0, a_fHeight / 2, outerY0), vector3(innerX1, a_fHeight / 2, innerY1), vector3(innerX0, a_fHeight / 2, innerY0));

		//bottom circle
		AddQuad(vector3(outerX0, -a_fHeight / 2, outerY0), vector3(outerX1, -a_fHeight / 2, outerY1), vector3(innerX0, -a_fHeight / 2, innerY0), vector3(innerX1, -a_fHeight / 2, innerY1)); 

		//outer wall
		AddQuad(vector3(outerX0, a_fHeight / 2, outerY0), vector3(outerX1, a_fHeight / 2, outerY1), vector3(outerX0, -a_fHeight / 2, outerY0), vector3(outerX1, -a_fHeight / 2, outerY1));

		//inner wall
		AddQuad(vector3(innerX1, a_fHeight / 2, innerY1), vector3(innerX0, a_fHeight / 2, innerY0), vector3(innerX1, -a_fHeight / 2, innerY1), vector3(innerX0, -a_fHeight / 2, innerY0));
	}

	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateTorus(float a_fOuterRadius, float a_fInnerRadius, int a_nSubdivisionsA, int a_nSubdivisionsB, vector3 a_v3Color)
{
	if (a_fOuterRadius < 0.01f)
		a_fOuterRadius = 0.01f;

	if (a_fInnerRadius < 0.005f)
		a_fInnerRadius = 0.005f;

	if (a_fInnerRadius > a_fOuterRadius)
		std::swap(a_fInnerRadius, a_fOuterRadius);

	if (a_nSubdivisionsA < 3)
		a_nSubdivisionsA = 3;
	if (a_nSubdivisionsA > 360)
		a_nSubdivisionsA = 360;

	if (a_nSubdivisionsB < 3)
		a_nSubdivisionsB = 3;
	if (a_nSubdivisionsB > 360)
		a_nSubdivisionsB = 360;

	Release();
	Init();

	// Replace this with your code

	//subdivisions a is for the cylinder faces and subdivisions b is for the number of cylinders
	//inverse index order for outer and inner ring
	std::vector<vector3> vertex;
	GLfloat faceRadius = a_fOuterRadius - a_fInnerRadius;
	GLfloat theta = 0; 
	GLfloat delta = static_cast<GLfloat>(2.0 * PI / static_cast<GLfloat>(a_nSubdivisionsB));
	GLfloat heightPlaceholder = 0.5f;

	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		vector3 temp = vector3(cos(theta) * faceRadius, sin(theta) * faceRadius, 0.0f);
		theta += delta;
		vertex.push_back(temp);
	}
	matrix4 transform = glm::translate(vector3(faceRadius, 0.0f, 0.0f));

	// modify those points in a negative height
	std::vector<vector3> vertexTop;
	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		vertexTop.push_back(
			transform * vector4(
				vertex[i] + vector3(0.0f, 0.0f, -heightPlaceholder / 2.0f), 1.0f)
		);
	}

	// modify those points in a positive height
	std::vector<vector3> vertexBottom;
	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		vertexBottom.push_back(vertex[i] + vector3(0.0f, 0.0f, heightPlaceholder / 2.0f));
	}

	//draw top circle
	vector3 origin = transform * vector4(0.0f, 0.0f, -heightPlaceholder/2.0f, 1.0f);
	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		AddTri(origin, vertexTop[(i + 1) % a_nSubdivisionsB], vertexTop[i]);
	}

	//draw bottom circle
	origin = vector3(0.0f, 0.0f, origin[0] / 2.0f);
	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		AddTri(origin, vertexBottom[i], vertexBottom[(i + 1) % a_nSubdivisionsB]);
	}

	//first tri
	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		AddTri(vertexBottom[i], vertexTop[i], vertexBottom[(i + 1) % a_nSubdivisionsB]);
	}

	for (int i = 0; i < a_nSubdivisionsB; i++)
	{
		AddTri(vertexBottom[(i + 1) % a_nSubdivisionsB], vertexTop[i], vertexTop[(i + 1) % a_nSubdivisionsB]);
	}

	/*
	for (uint j = 0; j < a_nSubdivisionsB; j++)
	{
		matrix4 m4Transform =
			glm::rotate(IDENTITY_M4, delta * j, vector3(0.0f, 1.0f, 0.0f)) *
			glm::translate(vector3(faceRadius * 2.0f, 0.0f, 0.0f));

		vector3 origin = m4Transform * vector4(0.0f, 0.0f, 0.0f, 1.0f);
		std::vector<vector3> temp;
		for (int i = 0; i < a_nSubdivisionsB; i++)
		{
			temp.push_back(m4Transform * vector4(vertex[i], 1.0f));
		}
		for (int i = 0; i < a_nSubdivisionsB; i++)
		{
			AddTri(origin, temp[i], temp[(i + 1) % a_nSubdivisionsB]);
		}

		
		// modify those points in a negative height
		std::vector<vector3> vertexTop;
		std::vector<vector3> tempTop;
		for (int i = 0; i < a_nSubdivisionsB; i++)
		{
			tempTop.push_back(vertex[i] + vector3(0.0f, 0.0f, -origin[0] / 2.0f));
			vertexTop.push_back(m4Transform * vector4(tempTop[i], 1.0f));
		}

		// modify those points in a positive height
		std::vector<vector3> vertexBottom;
		std::vector<vector3> tempBottom;
		for (int i = 0; i < a_nSubdivisionsB; i++)
		{
			tempBottom.push_back(vertex[i] + vector3(0.0f, 0.0f, origin[0] / 2.0f));
			vertexBottom.push_back(m4Transform * vector4(tempBottom[i], 1.0f));
		}
	

		//first tri
		for (int i = 0; i < a_nSubdivisionsB; i++)
		{
			AddTri(vertexBottom[i], vertexTop[i], vertexBottom[(i + 1) % a_nSubdivisionsB]);
		}

		for (int i = 0; i < a_nSubdivisionsB; i++)
		{
			AddTri(vertexBottom[(i + 1) % a_nSubdivisionsB], vertexTop[i], vertexTop[(i + 1) % a_nSubdivisionsB]);
		}
	}
	*/


	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::GenerateSphere(float a_fRadius, int a_nSubdivisions, vector3 a_v3Color)
{
	if (a_fRadius < 0.01f)
		a_fRadius = 0.01f;

	//Sets minimum and maximum of subdivisions
	if (a_nSubdivisions < 1)
	{
		GenerateCube(a_fRadius * 2.0f, a_v3Color);
		return;
	}
	if (a_nSubdivisions > 6)
		a_nSubdivisions = 6;

	Release();
	Init();

	// Replace this with your code
	std::vector<vector3> vertex;
	float xPos, yPos, zPos, xyPos; // vertex positions

	GLfloat delta = static_cast<GLfloat>(2.0 * PI / static_cast<GLfloat>(a_nSubdivisions));
	GLfloat deltaY = static_cast<GLfloat>(PI / static_cast<GLfloat>(a_nSubdivisions));
	float deltaAngle, deltaYAngle;

	for (uint i = 0; i <= a_nSubdivisions; i++)
	{
		deltaYAngle = PI / 2 - i * deltaY;
		xyPos = a_fRadius * cos(deltaYAngle);
		zPos = a_fRadius * sin(deltaYAngle);

		// add divisions + 1 vertices per division
		// first + last vertices have same position and normal, but different x
		for (int j = 0; j <= a_nSubdivisions; ++j)
		{
			deltaAngle = j * delta;

			//x and y positions
			xPos = xyPos * cos(deltaAngle);
			yPos = xyPos * sin(deltaAngle);

			vertex.push_back(vector3(xPos, yPos, zPos));
		}
	}


	// drawing sphere
	std::vector<int> indices;
	int currentIndex, nextIndex;
	for (int i = 0; i < a_nSubdivisions; i++)
	{
		currentIndex = i * (a_nSubdivisions + 1);     // beginning of current divsion
		nextIndex = currentIndex + a_nSubdivisions + 1;      // beginning of next division (current + subdivisions + 1)

		for (int j = 0; j < a_nSubdivisions; j++, currentIndex++, nextIndex++)
		{
			// 2 triangles per horizontal division not including first and last (1 tri per subdivision)
			// current , next , current + 1
			if (i != 0)
				AddTri(vertex[currentIndex], vertex[nextIndex], vertex[currentIndex + 1]);

			// current + 1 , next , next + 1
			if (i != (a_nSubdivisions - 1))
				AddTri(vertex[currentIndex + 1], vertex[nextIndex], vertex[nextIndex + 1]);
		}
	}
	// -------------------------------

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}
void MyMesh::AddTri(vector3 a_vBottomLeft, vector3 a_vBottomRight, vector3 a_vTopLeft)
{
	//C
	//| \
	//A--B
	//This will make the triangle A->B->C 
	AddVertexPosition(a_vBottomLeft);
	AddVertexPosition(a_vBottomRight);
	AddVertexPosition(a_vTopLeft);
}
void MyMesh::AddQuad(vector3 a_vBottomLeft, vector3 a_vBottomRight, vector3 a_vTopLeft, vector3 a_vTopRight)
{
	//C--D
	//|  |
	//A--B
	//This will make the triangle A->B->C and then the triangle C->B->D
	AddVertexPosition(a_vBottomLeft);
	AddVertexPosition(a_vBottomRight);
	AddVertexPosition(a_vTopLeft);

	AddVertexPosition(a_vTopLeft);
	AddVertexPosition(a_vBottomRight);
	AddVertexPosition(a_vTopRight);
}
void MyMesh::Init(void)
{
	m_bBinded = false;
	m_uVertexCount = 0;

	m_VAO = 0;
	m_VBO = 0;

	m_pShaderMngr = ShaderManager::GetInstance();
}
void MyMesh::Release(void)
{
	m_pShaderMngr = nullptr;

	if (m_VBO > 0)
		glDeleteBuffers(1, &m_VBO);

	if (m_VAO > 0)
		glDeleteVertexArrays(1, &m_VAO);

	m_lVertex.clear();
	m_lVertexPos.clear();
	m_lVertexCol.clear();
}
MyMesh::MyMesh()
{
	Init();
}
MyMesh::~MyMesh() { Release(); }
MyMesh::MyMesh(MyMesh& other)
{
	m_bBinded = other.m_bBinded;

	m_pShaderMngr = other.m_pShaderMngr;

	m_uVertexCount = other.m_uVertexCount;

	m_VAO = other.m_VAO;
	m_VBO = other.m_VBO;
}
MyMesh& MyMesh::operator=(MyMesh& other)
{
	if (this != &other)
	{
		Release();
		Init();
		MyMesh temp(other);
		Swap(temp);
	}
	return *this;
}
void MyMesh::Swap(MyMesh& other)
{
	std::swap(m_bBinded, other.m_bBinded);
	std::swap(m_uVertexCount, other.m_uVertexCount);

	std::swap(m_VAO, other.m_VAO);
	std::swap(m_VBO, other.m_VBO);

	std::swap(m_lVertex, other.m_lVertex);
	std::swap(m_lVertexPos, other.m_lVertexPos);
	std::swap(m_lVertexCol, other.m_lVertexCol);

	std::swap(m_pShaderMngr, other.m_pShaderMngr);
}
void MyMesh::CompleteMesh(vector3 a_v3Color)
{
	uint uColorCount = m_lVertexCol.size();
	for (uint i = uColorCount; i < m_uVertexCount; ++i)
	{
		m_lVertexCol.push_back(a_v3Color);
	}
}
void MyMesh::AddVertexPosition(vector3 a_v3Input)
{
	m_lVertexPos.push_back(a_v3Input);
	m_uVertexCount = m_lVertexPos.size();
}
void MyMesh::AddVertexColor(vector3 a_v3Input)
{
	m_lVertexCol.push_back(a_v3Input);
}
void MyMesh::CompileOpenGL3X(void)
{
	if (m_bBinded)
		return;

	if (m_uVertexCount == 0)
		return;

	CompleteMesh();

	for (uint i = 0; i < m_uVertexCount; i++)
	{
		//Position
		m_lVertex.push_back(m_lVertexPos[i]);
		//Color
		m_lVertex.push_back(m_lVertexCol[i]);
	}
	glGenVertexArrays(1, &m_VAO);//Generate vertex array object
	glGenBuffers(1, &m_VBO);//Generate Vertex Buffered Object

	glBindVertexArray(m_VAO);//Bind the VAO
	glBindBuffer(GL_ARRAY_BUFFER, m_VBO);//Bind the VBO
	glBufferData(GL_ARRAY_BUFFER, m_uVertexCount * 2 * sizeof(vector3), &m_lVertex[0], GL_STATIC_DRAW);//Generate space for the VBO

	// Position attribute
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 2 * sizeof(vector3), (GLvoid*)0);

	// Color attribute
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 2 * sizeof(vector3), (GLvoid*)(1 * sizeof(vector3)));

	m_bBinded = true;

	glBindVertexArray(0); // Unbind VAO
}
void MyMesh::Render(matrix4 a_mProjection, matrix4 a_mView, matrix4 a_mModel)
{
	// Use the buffer and shader
	GLuint nShader = m_pShaderMngr->GetShaderID("Basic");
	glUseProgram(nShader); 

	//Bind the VAO of this object
	glBindVertexArray(m_VAO);

	// Get the GPU variables by their name and hook them to CPU variables
	GLuint MVP = glGetUniformLocation(nShader, "MVP");
	GLuint wire = glGetUniformLocation(nShader, "wire");

	//Final Projection of the Camera
	matrix4 m4MVP = a_mProjection * a_mView * a_mModel;
	glUniformMatrix4fv(MVP, 1, GL_FALSE, glm::value_ptr(m4MVP));
	
	//Solid
	glUniform3f(wire, -1.0f, -1.0f, -1.0f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glDrawArrays(GL_TRIANGLES, 0, m_uVertexCount);  

	//Wire
	glUniform3f(wire, 1.0f, 0.0f, 1.0f);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glEnable(GL_POLYGON_OFFSET_LINE);
	glPolygonOffset(-1.f, -1.f);
	glDrawArrays(GL_TRIANGLES, 0, m_uVertexCount);
	glDisable(GL_POLYGON_OFFSET_LINE);

	glBindVertexArray(0);// Unbind VAO so it does not get in the way of other objects
}
void MyMesh::GenerateCuboid(vector3 a_v3Dimensions, vector3 a_v3Color)
{
	Release();
	Init();

	vector3 v3Value = a_v3Dimensions * 0.5f;
	//3--2
	//|  |
	//0--1
	vector3 point0(-v3Value.x, -v3Value.y, v3Value.z); //0
	vector3 point1(v3Value.x, -v3Value.y, v3Value.z); //1
	vector3 point2(v3Value.x, v3Value.y, v3Value.z); //2
	vector3 point3(-v3Value.x, v3Value.y, v3Value.z); //3

	vector3 point4(-v3Value.x, -v3Value.y, -v3Value.z); //4
	vector3 point5(v3Value.x, -v3Value.y, -v3Value.z); //5
	vector3 point6(v3Value.x, v3Value.y, -v3Value.z); //6
	vector3 point7(-v3Value.x, v3Value.y, -v3Value.z); //7

	//F
	AddQuad(point0, point1, point3, point2);

	//B
	AddQuad(point5, point4, point6, point7);

	//L
	AddQuad(point4, point0, point7, point3);

	//R
	AddQuad(point1, point5, point2, point6);

	//U
	AddQuad(point3, point2, point7, point6);

	//D
	AddQuad(point4, point5, point0, point1);

	// Adding information about color
	CompleteMesh(a_v3Color);
	CompileOpenGL3X();
}